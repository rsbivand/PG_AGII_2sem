% this program reads results (saved by katrina_job.m)
% and plots store-level total effects estimates

clear all;

load period1.mat;

total_obs = results.total_obs;

[nobs,nvars] = size(total_obs);

rho1 = results.rho;

Bpi = speye(n) - rho1*W;

% =================== start plots for Magazine Street
xi = xmat(:,2);
Bpx = Bpi\xi;
[Bpxs,ind] = sort(Bpx);
obs = unsort(total_obs(:,1),ind);

latt1 = []; 
long1 = [];
totalq = [];
for i=1:n;
if street(i,1) == 1
latt1 = [latt1
         latt(i,1)];
long1 = [long1
         long(i,1)];
totalq = [totalq
          obs(i,1)];

end;
end;

n1 = length(latt1);
h = plot3(latt1,long1,totalq(:,1),'+b', ...
latt1,long1,0.0*ones(n1,1),'.-k');
title('Flood depth Magazine Street');
xlabel('latitude');
ylabel('longitude');
zlabel('total effects estimates');
view([35 55]);
legend('0-3 months''stores');
pause;

xi = xmat(:,3);
Bpx = Bpi\xi;
[Bpxs,ind] = sort(Bpx);
obs = unsort(total_obs(:,2),ind);

latt1 = []; 
long1 = [];
totalq = [];
for i=1:n;
if street(i,1) == 1
latt1 = [latt1
         latt(i,1)];
long1 = [long1
         long(i,1)];
totalq = [totalq
          obs(i,1)];

end;
end;


plot3(latt1,long1,totalq(:,1),'+b', ...
latt1,long1,0.0*ones(n1,1),'.-k');
title('(logged) Median income Magazine Street');
xlabel('latitude');
ylabel('longitude');
zlabel('total effects estimates');
legend('0-3 months','stores');
view([35 55]);
pause;


xi = xmat(:,4);
Bpx = Bpi\xi;
[Bpxs,ind] = sort(Bpx);
obs = unsort(total_obs(:,3),ind);


latt1 = []; 
long1 = [];
totalq = [];
for i=1:n;
if street(i,1) == 1
latt1 = [latt1
         latt(i,1)];
long1 = [long1
         long(i,1)];
totalq = [totalq
          obs(i,1)];
end;
end;

plot3(latt1,long1,totalq(:,1),'+b', ...
latt1,long1,0.0*ones(n1,1),'.-k');
title('Small firm dummy Magazine Street');
xlabel('latitude');
ylabel('longitude');
zlabel('total effects estimates');
legend('0-3 months','stores');
view([35 55]);
pause;


xi = xmat(:,5);
Bpx = Bpi\xi;
[Bpxs,ind] = sort(Bpx);
obs = unsort(total_obs(:,4),ind);


latt1 = []; 
long1 = [];
totalq = [];
for i=1:n;
if street(i,1) == 1
latt1 = [latt1
         latt(i,1)];
long1 = [long1
         long(i,1)];
totalq = [totalq
          obs(i,1)];
end;
end;

plot3(latt1,long1,totalq(:,1),'+b', ...
latt1,long1,0.0*ones(n1,1),'.-k');
title('Large firm dummy Magazine Street');
xlabel('latitude');
ylabel('longitude');
zlabel('total effects estimates');
legend('0-3 months','stores');
view([35 55]);
pause;



xi = xmat(:,6);
Bpx = Bpi\xi;
[Bpxs,ind] = sort(Bpx);
obs = unsort(total_obs(:,5),ind);


latt1 = []; 
long1 = [];
totalq = [];
for i=1:n;
if street(i,1) == 1
latt1 = [latt1
         latt(i,1)];
long1 = [long1
         long(i,1)];
totalq = [totalq
          obs(i,1)];
end;
end;

plot3(latt1,long1,totalq(:,1),'+b', ...
latt1,long1,0.0*ones(n1,1),'.-k');
title('Low Social Status dummy Magazine Street');
xlabel('latitude');
ylabel('longitude');
zlabel('total effects estimates');
legend('0-3 months','stores');
view([35 55]);
pause;



xi = xmat(:,7);
Bpx = Bpi\xi;
[Bpxs,ind] = sort(Bpx);
obs = unsort(total_obs(:,6),ind);

latt1 = []; 
long1 = [];
totalq = [];
for i=1:n;
if street(i,1) == 1
latt1 = [latt1
         latt(i,1)];
long1 = [long1
         long(i,1)];
totalq = [totalq
          obs(i,1)];
end;
end;


plot3(latt1,long1,totalq(:,1),'+b', ...
latt1,long1,0.0*ones(n1,1),'.-k');
title('High Social Status dummy Magazine Street');
xlabel('latitude');
ylabel('longitude');
zlabel('total effects estimates');
legend('0-3 months','stores');
view([35 55]);
pause;



xi = xmat(:,8);
Bpx = Bpi\xi;
[Bpxs,ind] = sort(Bpx);
obs = unsort(total_obs(:,7),ind);


latt1 = []; 
long1 = [];
totalq = [];
for i=1:n;
if street(i,1) == 1
latt1 = [latt1
         latt(i,1)];
long1 = [long1
         long(i,1)];
totalq = [totalq
          obs(i,1)];
end;
end;

plot3(latt1,long1,totalq(:,1),'+b', ...
latt1,long1,0.0*ones(n1,1),'.-k');
title('Sole Proprietor dummy Magazine Street');
xlabel('latitude');
ylabel('longitude');
zlabel('total effects estimates');
legend('0-3 months','stores');
view([35 55]);
pause;




xi = xmat(:,9);
Bpx = Bpi\xi;
[Bpxs,ind] = sort(Bpx);
obs = unsort(total_obs(:,8),ind);

latt1 = []; 
long1 = [];
totalq = [];
for i=1:n;
if street(i,1) == 1
latt1 = [latt1
         latt(i,1)];
long1 = [long1
         long(i,1)];
totalq = [totalq
          obs(i,1)];
end;
end;


plot3(latt1,long1,totalq(:,1),'+b', ...
latt1,long1,0.0*ones(n1,1),'.-k');
title('National Chain dummy Magazine Street');
xlabel('latitude');
ylabel('longitude');
zlabel('total effects estimates');
legend('0-3 months','stores');
view([35 55]);

pause;

%================== end of Magazine street

% =================== start plots for Carrollton Street
xi = xmat(:,2);
Bpx = Bpi\xi;
[Bpxs,ind] = sort(Bpx);
obs = unsort(total_obs(:,1),ind);

latt1 = []; 
long1 = [];
totalq = [];
for i=1:n;
if street(i,1) == 2
latt1 = [latt1
         latt(i,1)];
long1 = [long1
         long(i,1)];
totalq = [totalq
          obs(i,1)];

end;
end;

n1 = length(latt1);
h = plot3(latt1,long1,totalq(:,1),'+b', ...
latt1,long1,0.0*ones(n1,1),'.-k');
title('Flood depth Carrollton Street');
xlabel('latitude');
ylabel('longitude');
zlabel('total effects estimates');
view([35 55]);
legend('0-3 months','stores');
pause;

xi = xmat(:,3);
Bpx = Bpi\xi;
[Bpxs,ind] = sort(Bpx);
obs = unsort(total_obs(:,2),ind);

latt1 = []; 
long1 = [];
totalq = [];
for i=1:n;
if street(i,1) == 2
latt1 = [latt1
         latt(i,1)];
long1 = [long1
         long(i,1)];
totalq = [totalq
          obs(i,1)];

end;
end;


plot3(latt1,long1,totalq(:,1),'+b', ...
latt1,long1,0.0*ones(n1,1),'.-k');
title('(logged) Median income Carrollton Street');
xlabel('latitude');
ylabel('longitude');
zlabel('total effects estimates');
legend('0-3 months','stores');
view([35 55]);
pause;


xi = xmat(:,4);
Bpx = Bpi\xi;
[Bpxs,ind] = sort(Bpx);
obs = unsort(total_obs(:,3),ind);


latt1 = []; 
long1 = [];
totalq = [];
for i=1:n;
if street(i,1) == 2
latt1 = [latt1
         latt(i,1)];
long1 = [long1
         long(i,1)];
totalq = [totalq
          obs(i,1)];
end;
end;

plot3(latt1,long1,totalq(:,1),'+b', ...
latt1,long1,0.0*ones(n1,1),'.-k');
title('Small firm dummy Carrollton Street');
xlabel('latitude');
ylabel('longitude');
zlabel('total effects estimates');
legend('0-3 months','stores');
view([35 55]);
pause;


xi = xmat(:,5);
Bpx = Bpi\xi;
[Bpxs,ind] = sort(Bpx);
obs = unsort(total_obs(:,4),ind);


latt1 = []; 
long1 = [];
totalq = [];
for i=1:n;
if street(i,1) == 2
latt1 = [latt1
         latt(i,1)];
long1 = [long1
         long(i,1)];
totalq = [totalq
          obs(i,1)];
end;
end;

plot3(latt1,long1,totalq(:,1),'+b', ...
latt1,long1,0.0*ones(n1,1),'.-k');
title('Large firm dummy Carrollton Street');
xlabel('latitude');
ylabel('longitude');
zlabel('total effects estimates');
legend('0-3 months','stores');
view([35 55]);
pause;



xi = xmat(:,6);
Bpx = Bpi\xi;
[Bpxs,ind] = sort(Bpx);
obs = unsort(total_obs(:,5),ind);


latt1 = []; 
long1 = [];
totalq = [];
for i=1:n;
if street(i,1) == 2
latt1 = [latt1
         latt(i,1)];
long1 = [long1
         long(i,1)];
totalq = [totalq
          obs(i,1)];
end;
end;

plot3(latt1,long1,totalq(:,1),'+b', ...
latt1,long1,0.0*ones(n1,1),'.-k');
title('Low Social Status dummy Carrollton Street');
xlabel('latitude');
ylabel('longitude');
zlabel('total effects estimates');
legend('0-3 months','stores');
view([35 55]);
pause;



xi = xmat(:,7);
Bpx = Bpi\xi;
[Bpxs,ind] = sort(Bpx);
obs = unsort(total_obs(:,6),ind);


latt1 = []; 
long1 = [];
totalq = [];
for i=1:n;
if street(i,1) == 2
latt1 = [latt1
         latt(i,1)];
long1 = [long1
         long(i,1)];
totalq = [totalq
          obs(i,1)];
end;
end;


plot3(latt1,long1,totalq(:,1),'+b', ...
latt1,long1,0.0*ones(n1,1),'.-k');
title('High Social Status dummy Carrollton Street');
xlabel('latitude');
ylabel('longitude');
zlabel('total effects estimates');
legend('0-3 months','stores');
view([35 55]);
pause;



xi = xmat(:,8);
Bpx = Bpi\xi;
[Bpxs,ind] = sort(Bpx);
obs = unsort(total_obs(:,7),ind);


latt1 = []; 
long1 = [];
totalq = [];
for i=1:n;
if street(i,1) == 2
latt1 = [latt1
         latt(i,1)];
long1 = [long1
         long(i,1)];
totalq = [totalq
          obs(i,1)];
end;
end;

plot3(latt1,long1,totalq(:,1),'+b', ...
latt1,long1,0.0*ones(n1,1),'.-k');
title('Sole Proprietor dummy Carrollton Street');
xlabel('latitude');
ylabel('longitude');
zlabel('total effects estimates');
legend('0-3 months','stores');
view([35 55]);
pause;




xi = xmat(:,9);
Bpx = Bpi\xi;
[Bpxs,ind] = sort(Bpx);
obs = unsort(total_obs(:,8),ind);


latt1 = []; 
long1 = [];
totalq = [];
for i=1:n;
if street(i,1) == 2
latt1 = [latt1
         latt(i,1)];
long1 = [long1
         long(i,1)];
totalq = [totalq
          obs(i,1)];
end;
end;


plot3(latt1,long1,totalq(:,1),'+b', ...
latt1,long1,0.0*ones(n1,1),'.-k');
title('National Chain dummy Carrollton Street');
xlabel('latitude');
ylabel('longitude');
zlabel('total effects estimates');
legend('0-3 months','stores');
view([35 55]);

pause;


%================== end of Carrollton


% =================== start plots for St Claude Street
xi = xmat(:,2);
Bpx = Bpi\xi;
[Bpxs,ind] = sort(Bpx);
obs = unsort(total_obs(:,1),ind);

latt1 = []; 
long1 = [];
totalq = [];
for i=1:n;
if street(i,1) == 3
latt1 = [latt1
         latt(i,1)];
long1 = [long1
         long(i,1)];
totalq = [totalq
          obs(i,1)];

end;
end;

n1 = length(latt1);
h = plot3(latt1,long1,totalq(:,1),'+b', ...
latt1,long1,0.0*ones(n1,1),'.-k');
title('Flood depth St Claude Street');
xlabel('latitude');
ylabel('longitude');
zlabel('total effects estimates');
view([160 55]);
legend('0-3 months','stores');
pause;

xi = xmat(:,3);
Bpx = Bpi\xi;
[Bpxs,ind] = sort(Bpx);
obs = unsort(total_obs(:,2),ind);

latt1 = []; 
long1 = [];
totalq = [];
for i=1:n;
if street(i,1) == 3
latt1 = [latt1
         latt(i,1)];
long1 = [long1
         long(i,1)];
totalq = [totalq
          obs(i,1)];

end;
end;


plot3(latt1,long1,totalq(:,1),'+b', ...
latt1,long1,0.0*ones(n1,1),'.-k');
title('(logged) Median income St Claude Street');
xlabel('latitude');
ylabel('longitude');
zlabel('total effects estimates');
legend('0-3 months','stores');
view([160 55]);
pause;


xi = xmat(:,4);
Bpx = Bpi\xi;
[Bpxs,ind] = sort(Bpx);
obs = unsort(total_obs(:,3),ind);


latt1 = []; 
long1 = [];
totalq = [];
for i=1:n;
if street(i,1) == 3
latt1 = [latt1
         latt(i,1)];
long1 = [long1
         long(i,1)];
totalq = [totalq
          obs(i,1)];
end;
end;

plot3(latt1,long1,totalq(:,1),'+b', ...
latt1,long1,0.0*ones(n1,1),'.-k');
title('Small firm dummy St Claude Street');
xlabel('latitude');
ylabel('longitude');
zlabel('total effects estimates');
legend('0-3 months','stores');
view([160 55]);
pause;


xi = xmat(:,5);
Bpx = Bpi\xi;
[Bpxs,ind] = sort(Bpx);
obs = unsort(total_obs(:,4),ind);


latt1 = []; 
long1 = [];
totalq = [];
for i=1:n;
if street(i,1) == 3
latt1 = [latt1
         latt(i,1)];
long1 = [long1
         long(i,1)];
totalq = [totalq
          obs(i,1)];
end;
end;

plot3(latt1,long1,totalq(:,1),'+b', ...
latt1,long1,0.0*ones(n1,1),'.-k');
title('Large firm dummy St Claude Street');
xlabel('latitude');
ylabel('longitude');
zlabel('total effects estimates');
legend('0-3 months','stores');
view([160 55]);
pause;



xi = xmat(:,6);
Bpx = Bpi\xi;
[Bpxs,ind] = sort(Bpx);
obs = unsort(total_obs(:,5),ind);


latt1 = []; 
long1 = [];
totalq = [];
for i=1:n;
if street(i,1) == 3
latt1 = [latt1
         latt(i,1)];
long1 = [long1
         long(i,1)];
totalq = [totalq
          obs(i,1)];
end;
end;

plot3(latt1,long1,totalq(:,1),'+b', ...
latt1,long1,0.0*ones(n1,1),'.-k');
title('Low Social Status dummy St Claude Street');
xlabel('latitude');
ylabel('longitude');
zlabel('total effects estimates');
legend('0-3 months','stores');
view([160 55]);
pause;



xi = xmat(:,7);
Bpx = Bpi\xi;
[Bpxs,ind] = sort(Bpx);
obs = unsort(total_obs(:,6),ind);


latt1 = []; 
long1 = [];
totalq = [];
for i=1:n;
if street(i,1) == 3
latt1 = [latt1
         latt(i,1)];
long1 = [long1
         long(i,1)];
totalq = [totalq
          obs(i,1)];
end;
end;


plot3(latt1,long1,totalq(:,1),'+b', ...
latt1,long1,0.0*ones(n1,1),'.-k');
title('High Social Status dummy St Claude Street');
xlabel('latitude');
ylabel('longitude');
zlabel('total effects estimates');
legend('0-3 months','stores');
view([160 55]);
pause;



xi = xmat(:,8);
Bpx = Bpi\xi;
[Bpxs,ind] = sort(Bpx);
obs = unsort(total_obs(:,7),ind);


latt1 = []; 
long1 = [];
totalq = [];
for i=1:n;
if street(i,1) == 3
latt1 = [latt1
         latt(i,1)];
long1 = [long1
         long(i,1)];
totalq = [totalq
          obs(i,1)];
end;
end;

plot3(latt1,long1,totalq(:,1),'+b', ...
latt1,long1,0.0*ones(n1,1),'.-k');
title('Sole Proprietor dummy St Claude Street');
xlabel('latitude');
ylabel('longitude');
zlabel('total effects estimates');
legend('0-3 months','stores');
view([160 55]);
pause;




xi = xmat(:,9);
Bpx = Bpi\xi;
[Bpxs,ind] = sort(Bpx);
obs = unsort(total_obs(:,8),ind);


latt1 = []; 
long1 = [];
totalq = [];
for i=1:n;
if street(i,1) == 3
latt1 = [latt1
         latt(i,1)];
long1 = [long1
         long(i,1)];
totalq = [totalq
          obs(i,1)];
end;
end;


plot3(latt1,long1,totalq(:,1),'+b', ...
latt1,long1,0.00*ones(n1,1),'.-k');
title('National Chain dummy St Claude Street');
xlabel('latitude');
ylabel('longitude');
zlabel('total effects estimates');
legend('0-3 months','stores');
view([160 55]);

pause;


%================== end of St Claude
