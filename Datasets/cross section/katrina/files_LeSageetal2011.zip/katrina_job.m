% Magazine + Carrollton + St. Claude streets

clear all;

% ========== read data for 3 streets


a = load('magazine_data.txt');

code = a(:,2);
data = a(:,3:end);

n = length(code);

streetdum = ones(n,1);

data = [data streetdum];


[a,b] = xlsread('magazine_lattlong2.xls');

code2 = a(:,1);
latt = a(:,2);
long = a(:,3);

% =========== match to latt-long
out = [];
for i=1:n;
    codei = code(i,1);
    ind = find(code2 == codei);
    if (length(ind) == 1)
        out = [out
               codei latt(ind,1) long(ind,1) data(i,:)];
     elseif (length(ind) > 1)
      for j=1:length(ind);
        out = [out
               codei latt(ind(j),1) long(ind(j),1) data(i+j-1,:)];
      end;
    elseif (length(ind) == 0)
        disp('no match');
        codei
    end;
end;


a = load('carrollton_data.txt');

code = a(:,2);
data = a(:,3:end);

n = length(code);

streetdum = ones(n,1)*2;

data = [data streetdum];

[a,b] = xlsread('carrollton_lattlong2.xls');


code2 = a(:,1);
latt = a(:,2);
long = a(:,3);

for i=1:n;
    codei = code(i,1);
    ind = find(code2 == codei);
    if (length(ind) == 1)
        out = [out
               codei latt(ind,1) long(ind,1) data(i,:)];
    elseif (length(ind) > 1)
        disp('more than one match');
        codei
    elseif (length(ind) == 0)
        disp('no match');
        codei
    end;
end;

% ========== read data for three streets

a = load('claude_data.txt');

code = a(:,2);
data = a(:,3:end);

n = length(code);

streetdum = ones(n,1)*3;

data = [data streetdum];


[a,b] = xlsread('claude_lattlong2.xls');

code2 = a(:,1);
latt = a(:,2);
long = a(:,3);

for i=1:n;
    codei = code(i,1);
    ind = find(code2 == codei);
    if (length(ind) == 1)
        out = [out
               codei latt(ind,1) long(ind,1) data(i,:)];
    elseif (length(ind) == 2)
        disp('more than one match');
        codei
    elseif (length(ind) == 0)
        disp('no match');
        codei
    end;
end;


days=out(:,14);

n = length(days);
nobs = n;
% split the data into months
qtr1 = find(days < 90);
qtr2 = find(days > 90 & days < 180);
qtr3 = find(days > 180 & days < 365);
qtr4 = find(days > 450);


% write out to a file
% firms that re-opened in near, medium and longer term

         
y1 = zeros(n,1);
y2 = y1;
y3 = y1;

y1(qtr1,1) = 1;
y2 = y1;
y2(qtr2,1) = 1;
y3 = y2;
y3(qtr3,1) = 1;
          
dataout = out;

         
address = dataout(:,1);
latt = dataout(:,2);
long = dataout(:,3);
street = dataout(:,end);
medinc = dataout(:,5);
perinc = dataout(:,6);
elevation = dataout(:,7);
flood= -dataout(:,8);
owntype = dataout(:,9);
sesstatus = dataout(:,10);
sizeemp = dataout(:,11);
openstatus1 = dataout(:,12);
openstatus2 = dataout(:,13);
days = dataout(:,14);
streetdums = dummyvar(street);


owntypedums=dummyvar(owntype);
sesstatusdums=dummyvar(sesstatus);
sizedums=dummyvar(sizeemp);


W = make_neighborsw(latt,long,11);
n = size(W,1);


xo=[flood log(medinc) sizedums(:,1) sizedums(:,3) sesstatusdums(:,1)+sesstatusdums(:,2) ...
 sesstatusdums(:,4)+sesstatusdums(:,5) owntypedums(:,1) owntypedums(:,3) ];


n = size(xo,1);

xmat = [ones(n,1) xo];

vnames = strvcat('y=open','constant','flood depth','log(median income)', ...
    'small size','large size','low ses','high ses', ...
    'ownerdum1','ownerdum2');

ndraw = 600
nomit = 100;
prior.nsample=1;

% ndraw = 2500
% nomit = 500;
% prior.nsample=5;

results = sarpx_g(y1,xmat,W,ndraw,nomit,prior);
prt(results,vnames);

save period1.mat;

% do effects estimates
% =======================================================
% a set of draws for the effects/impacts distribution
total    = results.total;
indirect = results.indirect;
direct   = results.direct;

total_obs = results.total_obs;

% should be 673 effects for all observations
total_obs

% Compute means, std deviation and upper and lower 0.99 intervals
iter = ndraw-nomit;
p = results.p;
total_out = zeros(p,5);
total_save = zeros(ndraw-nomit,p);
for i=1:p;
tmp = (total(:,i)); % an ndraw by 1 by ntraces matrix
total_mean = mean(tmp);
total_std = std(tmp);
% Bayesian 0.99 credible intervals
% for the cumulative total effects
total_save(:,i) = tmp;
bounds = cr_interval(tmp,0.99);
ubounds = bounds(1,1);
lbounds = bounds(1,2);
total_out(i,:) = [lbounds total_mean  ubounds total_mean/total_std tdis_prb(total_mean/total_std,nobs)];
end;

% now do indirect effects
indirect_out = zeros(p,5);
for i=1:p;
tmp = (indirect(:,i)); % an ndraw by 1 vector
indirect_mean = mean(tmp);
indirect_std = std(tmp);
% Bayesian 0.95 credible intervals
% for the cumulative indirect effects
bounds = cr_interval(tmp,0.99);
ubounds = bounds(1,1);
lbounds = bounds(1,2);
indirect_out(i,:) = [lbounds indirect_mean ubounds indirect_mean/indirect_std tdis_prb(indirect_mean/indirect_std,nobs)];
end;


% now do direct effects
direct_out = zeros(p,5);
for i=1:p;
tmp = (direct(:,i)); % an ndraw by 1 by ntraces matrix
direct_mean = mean(tmp);
direct_std = std(tmp);
% Bayesian 0.95 credible intervals
% for the cumulative direct effects
bounds = cr_interval(tmp,0.99);
ubounds = bounds(1,1);
lbounds = bounds(1,2);
direct_out(i,:) = [lbounds direct_mean ubounds direct_mean/direct_std tdis_prb(direct_mean/direct_std,nobs)];
end;


% now print x-effects estimates

bstring = 'Coefficient'; 
tstring = 'mean/std'; 
pstring = 't-prob';
lstring = 'lower 01';
ustring = 'upper 99';
cnames = strvcat(lstring, bstring, ustring, tstring, pstring);
ini.cnames = cnames;
ini.width = 2000;

% print effects estimates

cflag = 1;

if cflag == 1
vnameso = strvcat(vnames(3:end,:));
elseif cflag == 0
vnameso = strvcat(vnames(2:end,:));
end    
ini.rnames = strvcat('Direct',vnameso);
ini.fmt = '%16.6f';
ini.fid = 1;

% set up print out matrix
printout = direct_out;
mprint(printout,ini);

printout = indirect_out;
ini.rnames = strvcat('Indirect',vnameso);
mprint(printout,ini);

printout = total_out;
ini.rnames = strvcat('Total',vnameso);
mprint(printout,ini);


