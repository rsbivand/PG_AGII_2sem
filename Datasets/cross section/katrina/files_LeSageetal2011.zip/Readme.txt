Readme.txt

MATLAB program files and data files
to produce MCMC spatial probit estimates
for binary probit store operating status on 3 streets in New Orleans
NOTE:
Use of these programs requires that you download the freely
available spatial econometrics toolbox functions
from: www.spatial-econometrics.com since the
toolbox contains support/utility functions used by these programs


data files (with data for stores located on 3 streets):
carrollton_data.txt
claude_data.txt
magazine_data.txt
(see katrina_job.m file for variable definitions)

data files containing latitude-longitude coordinates of stores
carrollton_lattlong2.xls
claude_lattlong2.xls
magazine_lattlong2.xls

katrina_job.m, a program file that reads data files and calls function
sarpx_g.m to carry out MCMC estimation
and calls
prt.m - a function to print out estimation results
cr_interval.m - a support function for calculating confidence intervals

plot_effects.m - a program to plot store-level effects
for all three streets, which uses results stored in
a MATLAB file named period1.mat created by the
program katrina_job.m, which must be executed first
