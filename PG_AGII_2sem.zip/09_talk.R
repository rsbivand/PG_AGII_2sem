
## ----est1, size="footnotesize", message=FALSE---------------------------------
Sys.setenv("PROJ_NETWORK"="ON")
library(spdep)
lw <- nb2listw(unb, style="W")
library(spatialreg)
e <- eigenw(lw)


## ----est2, size="footnotesize", message=FALSE---------------------------------
SEM_pre_maj <- errorsarlm(form_pre_maj, data=eng324, listw=lw, control=list(pre_eig=e), quiet=FALSE)


## ----est3, size="footnotesize", message=FALSE---------------------------------
SAC_pre_maj <- sacsarlm(form_pre_maj, data=eng324, listw=lw, control=list(pre_eig1=e, pre_eig2=e), llprof=40)
SAC_track <- capture.output(sac <- sacsarlm(form_pre_maj, data=eng324, listw=lw, control=list(pre_eig1=e, pre_eig2=e), quiet=FALSE))
c(SAC_pre_maj$rho, SAC_pre_maj$lambda)
c(SAC_pre_maj$rho/SAC_pre_maj$rho.se, SAC_pre_maj$lambda/SAC_pre_maj$lambda.se)


## ----est4, size="footnotesize", message=FALSE---------------------------------
#| label: est4
#| fig-cap: SAC pre-CCT with political control model log likelihood surface and optimiser path to optimum
m <- -matrix(SAC_pre_maj$llprof$ll, 40, 40)
con <- textConnection(SAC_track)
sac_track <- read.table(con, skip=14)
close(con)
contour(SAC_pre_maj$llprof$xseq, SAC_pre_maj$llprof$yseq, m, levels=quantile(c(m), seq(0,1,0.1)), xlab="rho", ylab="lambda", col="blue4")
abline(h=SAC_pre_maj$rho, v=SAC_pre_maj$lambda, lwd=3, col="grey")
lines(sac_track$V2, sac_track$V4, col="brown3")


## ----bayes1, size="footnotesize", eval=FALSE----------------------------------
## set.seed(12345)
## SAC_bayes <- spBreg_sac(form_pre_maj, data=eng324, listw=lw, control=list(ndraw=20000L, nomit=2000L))

## ----bayes1a, size="footnotesize", echo=FALSE---------------------------------
SAC_bayes <- readRDS("Input_output/SAC_bayes.rds")


## ----bayes2, size="footnotesize"----------------------------------------------
summary(SAC_bayes[, c("rho", "lambda", "sige")])


## ----bayes3, size="footnotesize"----------------------------------------------
#| label: bayes3
#| fig-cap: Sampling traces and density plots for spatial coefficients and $\sigma^2$, SAC model with political control, MCMC, 20,000 draws
opar <- par(mfrow=c(2, 1)) 
plot(SAC_bayes[, c("rho", "lambda", "sige")], smooth=TRUE)
par(opar)


## ----gmm1, size="footnotesize"------------------------------------------------
library(sphet)
SAC_gmm <- spreg(form_pre_maj, data=eng324, listw=lw, model="sarar")
c(coef(SAC_gmm)[c("lambda", "rho"),], s2=as.numeric(SAC_gmm$s2))

