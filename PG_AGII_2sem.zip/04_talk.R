
## ----pom_sw1, size="footnotesize"---------------------------------------------
Sys.setenv("PROJ_NETWORK"="ON")
library(sf)
library(spdep)
(pom6a |> poly2nb(queen=FALSE,
 row.names=pom6a$TERYT) -> pom_rook_nb)


## ----pom_sw2, size="footnotesize"---------------------------------------------
(pom6a |> poly2nb(queen=TRUE,
 row.names=pom6a$TERYT) -> pom_queen_nb)


## ----pom_sw3, size="footnotesize"---------------------------------------------
(pom6a |> poly2nb(queen=FALSE, row.names=pom6a$TERYT,
 snap=0.00001) -> pom_rook_nb)
(pom6a |> poly2nb(queen=TRUE, row.names=pom6a$TERYT,
 snap=0.00001) -> pom_queen_nb)


## ----pom_sw4, size="footnotesize"---------------------------------------------
#| label: pom_sw4
#| fig-cap: Queen neighbour object, Pomeranian municipalities, 2022
geom <- st_geometry(pom6a) 
plot(geom, border="grey")
plot(pom_queen_nb, geom, add=TRUE)


## ----pom_sw5, size="footnotesize"---------------------------------------------
(geom |> st_point_on_surface() |> knearneigh(k=5) |>
 knn2nb(row.names=pom6a$TERYT) -> pom_k5_nb)

## ----pom_sw6, size="footnotesize"---------------------------------------------
#| label: pom_sw6
#| fig-cap: Five nearest neighbour object, Pomeranian municipalities, 2022
plot(geom, border="grey")
plot(pom_k5_nb, geom, add=TRUE)


## ----gd_sw1, size="footnotesize"----------------------------------------------
(gd_takeaways|> knearneigh(k=5) |>
 knn2nb(row.names=gd_takeaways$osm_id) -> gd_k5_nb)

## ----gd_sw1a, size="footnotesize"---------------------------------------------
gd_k5_nb |> nb2lines(coords=st_geometry(gd_takeaways)
 ) -> gd_k5_nb_sf


## ----gd_sw2a, size="footnotesize", eval=!knitr::is_latex_output()-------------
#| label: gd_sw2a
#| fig-cap: Five nearest neighbour object, Gdańsk take-away outlets, OpenStreetMap
library(mapview)
mapview(gd_takeaways) + mapview(gd_k5_nb_sf, color="red4")

## ----pom_sw7, size="footnotesize"---------------------------------------------
pom_queen_nb |> nb2listw(style="W") -> pom_queen_lw
summary(pom_queen_lw)


## ----pom_sw8, size="footnotesize"---------------------------------------------
pom_queen_lw$weights |> sapply(sum) |> unique()


## ----gar_read0, size="footnotesize"-------------------------------------------
library(sf)
eng324 <- st_read("Datasets/eng324s.gpkg")


## ----gar_vis0, size="footnotesize"--------------------------------------------
#| label: gar_vis0
#| fig-cap: Direct service organisation chosen, compulsory competitive tendering, English districts
library(mapview)
mapview(eng324, zcol="f_dso")


## ----gar_sw0, size="footnotesize"---------------------------------------------
library(spdep)
(pnb <- poly2nb(eng324, queen=TRUE, row.names=eng324$NAME))


## ----gar_sw1, size="footnotesize"---------------------------------------------
crds <- st_centroid(st_geometry(eng324))
k2 <- knn2nb(knearneigh(crds, k=2), row.names=eng324$NAME)
(unb <- make.sym.nb(union.nb(pnb, k2)))


## ----gar_sw2, size="footnotesize"---------------------------------------------
#| label: gar_sw2
#| fig-cap: Contiguity neighbours and added k-nearest neighbours, 324 Englist districts
pnb_sf <- nb2lines(pnb, coords=crds)
k2_sf <- nb2lines(setdiff.nb(intersect.nb(pnb, k2), k2),
 coords=crds)
mapview(eng324, alpha.regions=0.15) +
 mapview(pnb_sf, color="blue3") +
 mapview(k2_sf, color="red4")


## ----gar_sw3, size="footnotesize"---------------------------------------------
(orignb <- read.gal("Datasets/eng324_orig.gal"))
attr(orignb, "region.id") <- attr(unb, "region.id")

## ----gar_sw4, size="footnotesize"---------------------------------------------
#| label: gar_sw4
#| fig-cap: Original simple graph, 324 English districts
orignb_sf <- nb2lines(orignb, coords=crds)
mapview(eng324, alpha.regions=0.15) +
 mapview(orignb_sf, color="green4")


