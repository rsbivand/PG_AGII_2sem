## ----chile1, size="footnotesize"----------------------------------------------
Sys.setenv("PROJ_NETWORK"="ON")
library(sf)

## ----chile1a, size="footnotesize", message=FALSE------------------------------
library(chilemapas)

## ----chile1b, size="footnotesize"---------------------------------------------
mapa_comunas |> data.frame() |> 
  st_as_sf(sf_column_name="geometry") -> mc_sf
mc_sf


## ----chile2, size="footnotesize"----------------------------------------------
st_geometry(mc_sf)


## ----chile3, size="footnotesize"----------------------------------------------
mc_sf |> subset(subset=codigo_region == "07") -> maule_sf
maule_sf |> st_union() |> st_area() |> units::set_units("km2")


## ----chile4, size="footnotesize"----------------------------------------------
st_agr(maule_sf)
maule_sf |> st_centroid() -> maule_sf_pt1


## ----chile5, size="footnotesize"----------------------------------------------
maule_sf |> st_geometry() |> st_centroid() -> maule_sfc_pt2


## ----chile6, size="footnotesize"----------------------------------------------
maule_sf |> 
  st_set_agr(c(codigo_comuna="identity",
               codigo_provincia="identity", 
               codigo_region="constant")
            ) -> maule_sf_agr
st_agr(maule_sf_agr)
maule_sf_agr |> st_centroid() -> maule_sf_pt3


## ----chile7, size="footnotesize"----------------------------------------------
library(elevatr)
library(terra)
maule_sf |>  get_elev_raster(z = 7,
 clip = "locations", neg_to_na = TRUE) |> 
 rast() -> maule_elev
maule_elev


## ----chile8, size="footnotesize"----------------------------------------------
maule_sf |> subset(subset = codigo_comuna=="07101") -> talca_sf
library(osmdata)
talca_sf |> st_bbox() |> opq() |>
 add_osm_feature(key = "names") -> talca_q


## ----chile8a, size="footnotesize", eval=FALSE---------------------------------
talca_q |> osmdata_sf() -> talca_osm_sf

## ----chile8c, size="footnotesize"---------------------------------------------
talca_osm_sf


## ----chile9, size="footnotesize"----------------------------------------------
talca_osm_sf$osm_points -> talca_pts
talca_pts |> subset(subset = !is.na(takeaway), 
 select = c(osm_id, name, amenity, cuisine,
  takeaway, geometry)) -> talca_takeaways
talca_takeaways


## ----pl1, size="footnotesize"-------------------------------------------------
library(rgugik)
gd_sf <- borders_get(county = "Gdańsk")
gd_sf


## ----pl2, size="footnotesize"-------------------------------------------------
gd_sf |>  get_elev_raster(z = 9,
 clip = "locations", neg_to_na = TRUE) |> rast() -> gd_elev
gd_elev


## ----pl3, size="footnotesize"-------------------------------------------------
gd_sf |> st_transform(crs = "OGC:CRS84") |> st_bbox() |>
 opq() |> add_osm_feature(key = "amenity") -> gd_q

## ----pl3a, size="footnotesize", eval=FALSE------------------------------------
gd_q |> osmdata_sf() -> gd_osm_sf

## ----pl3c, size="footnotesize"------------------------------------------------
gd_osm_sf


## ----pl4, size="footnotesize"-------------------------------------------------
gd_osm_sf$osm_points -> gd_pts
gd_pts |> subset(subset = !is.na(takeaway),
 select = c(osm_id, name, amenity, cuisine,
  takeaway, geometry)) -> gd_takeaways
gd_takeaways


## ----chile-crs1, size="footnotesize"------------------------------------------
st_crs(talca_sf)


## ----chile-crs2, size="footnotesize"------------------------------------------
st_crs(talca_takeaways)


## ----chile-crs3, size="footnotesize"------------------------------------------
try(st_within(talca_takeaways, talca_sf))


## ----chile-crs4, size="footnotesize"------------------------------------------
talca_sf |> st_crs() -> sirgas2000
talca_takeaways |> st_set_crs(sirgas2000) |>
 st_within(talca_sf) |> unlist() |> as.logical()


## ----chile-crs5, size="footnotesize"------------------------------------------
st_crs("EPSG:31979")


## ----chile-crs6, size="footnotesize"------------------------------------------
sf_proj_network(TRUE)
sf_proj_pipelines("EPSG:4674", "EPSG:31979")


## ----chile-crs6a, size="footnotesize"-----------------------------------------
sf_proj_pipelines("EPSG:4674", "EPSG:20049")


## ----chile-crs7, size="footnotesize"------------------------------------------
maule_sf |> st_union() |> st_transform(crs = "EPSG:31979") |>
 st_area() |> units::set_units("km2")


## ----pl-crs1, size="footnotesize"---------------------------------------------
st_crs(gd_sf)


## ----pl-crs2, size="footnotesize"---------------------------------------------
st_crs(gd_takeaways)


## ----pl-crs3, size="footnotesize"---------------------------------------------
sf_proj_pipelines("EPSG:2180", "EPSG:4326")


## ----crs-osgb1, size="footnotesize"-------------------------------------------
st_crs("EPSG:27700")


## ----crs-osgb2, size="footnotesize"-------------------------------------------
sf_proj_pipelines("EPSG:27700", "EPSG:4326")


