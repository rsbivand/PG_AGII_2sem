
## ----pl_m0, size="footnotesize"-----------------------------------------------
Sys.setenv("PROJ_NETWORK"="ON")
library(rgugik)
library(sf)
substring(commune_names$TERYT, 1, 2) -> vpom
commune_names |> subset(subset = vpom == "22") -> pom0


## ----pl_m1, size="footnotesize", eval=FALSE-----------------------------------
borders_get(TERYT = pom0$TERYT) -> pom


## ----pl_m1b, size="footnotesize"----------------------------------------------
ID <- as.integer("0012345") 
str(ID)
formatC(ID, format="d", width=7, flag="0")


## ----pl_m2, size="footnotesize"-----------------------------------------------
dim(pom)
pom |> sapply(class) |> str()
str(pom$TERYT)
str(pom0)


## ----pl_m2a, size="footnotesize"----------------------------------------------
pom$TERYT <- sub("_", "", pom$TERYT)
any(is.na(match(pom$TERYT, pom0$TERYT)))


## ----pl_m3, size="footnotesize"-----------------------------------------------
pom |> merge(pom0, by = "TERYT") -> pom1 
pom1


## ----pl_m4, size="footnotesize", eval=FALSE-----------------------------------
pop22 <- read.csv("sd/LUDN_2577_2022.csv", sep=";")


## ----pl_m5, size="footnotesize"-----------------------------------------------
sapply(pop22, class)
pop22$Kod <- as.character(pop22$Kod)
names(pop22)[3:8] <- c("m_u15", "f_u15",
 "m_15_64", "f_15_59", "m_o65", "k_o60")
pop22$type <- factor(substring(pop22$Kod, 7, 7),
 levels = c("1", "2", "3"),
 labels = c("urban", "rural", "urban_rural"))
names(pop22)


## ----pl_m6, size="footnotesize"-----------------------------------------------
pom1 |> merge(pop22[, -9], by.x = "TERYT",
 by.y = "Kod") -> pom2
pom2


## ----pl_m7, size="footnotesize"-----------------------------------------------
pom2 |> st_drop_geometry() |> subset(select = 4:9) |>
 apply(1, function(x) sum(x)) -> pom2$pop
pom2 |> st_area() |>
 units::set_units("km2") -> pom2$area_km2
pom2 |> st_drop_geometry() |>
 subset(select = c(pop, area_km2)) |>
 apply(1, function(x) x[1]/x[2]) -> pom2$density
 pom2


## ----pl_m8a, size="footnotesize", eval=FALSE----------------------------------
ag20 <- read.csv("sd/POWS_4139_2020.csv", sep=",")


## ----pl_m9, size="footnotesize"-----------------------------------------------
ag20$Kod <- as.character(ag20$Kod)
names(ag20)[3:7] <- c("farm", "non_farm_business",
 "non_farm_wages", "pension", "other_non_wage")
pom2 |> merge(ag20[,-2], by.x = "TERYT",
 by.y = "Kod") -> pom3


## ----pl_m10a, size="footnotesize", eval=FALSE---------------------------------
cen21 <- read.csv("Datasets/sd/NARO_4383_2021.csv", sep=";")


## ----pl_m10c, size="footnotesize"---------------------------------------------
cen21$Kod <- as.character(cen21$Kod)
names(cen21)[3] <- "dwellings"
pom3 |> merge(cen21[, -c(2, 4)], by.x = "TERYT",
 by.y = "Kod") -> pom4
names(pom4)


## ----pl_m11, size="footnotesize"----------------------------------------------
agrs <- factor(c(rep("identity", 3), rep("aggregate", 6),
 "identity", rep("aggregate", 9)),
 levels=c("constant", "aggregate", "identity"))
names(agrs) <- names(st_drop_geometry(pom4))
pom4 |> st_set_agr(agrs) -> pom5


## ----chile_vis1a, size="footnotesize"-----------------------------------------
#| label: base_cl
#| fig-cap: Elevation of Región del Maule, municipalities (base graphics plot methods)
library(elevatr)
library(terra)
maule_sf |>  get_elev_raster(z = 7,
 clip = "locations", neg_to_na = TRUE) |> 
 rast() -> maule_elev
plot(maule_elev, col=rev(hcl.colors(50, "Dark Mint")))
plot(st_geometry(maule_sf), add=TRUE)
text(st_coordinates(st_centroid(st_geometry(maule_sf))),
 label=maule_sf$codigo_comuna)


## ----chile_vis1b, size="footnotesize"-----------------------------------------
#| label: mapsf_cl
#| fig-cap: Elevation of Región del Maule, municipalities (base graphics mapsf functions)
library(mapsf)
mf_raster(maule_elev, leg_pos="bottomleft",
 leg_title="elevation (m)", leg_horiz=TRUE,
 leg_size=0.8, leg_val_rnd=0)
mf_map(st_geometry(maule_sf), add=TRUE, lwd=2,
 border="grey60", col="transparent")
mf_label(maule_sf, var="codigo_comuna", overlap=FALSE,
 halo=2)


## ----chile_vis2a, size="footnotesize"-----------------------------------------
#| label: tmap3_cl
#| fig-cap: Elevation of Región del Maule, municipalities (trellis graphics tmap functions)
library(tmap)
tm_shape(maule_elev) + tm_raster(n=15,
 palette=rev(hcl.colors(7, "Dark Mint"))) +
 tm_shape(maule_sf) + tm_borders() +
 tm_text("codigo_comuna")


## ----chile_vis2, size="footnotesize"------------------------------------------
#| label: takeaways_talca1
#| fig-cap: Location of take-away outlets in Talca
plot(st_geometry(talca_sf))
plot(st_geometry(talca_takeaways), pch=4, col=3,
 cex=2, lwd=2, add=TRUE)


## ----chile_vis3a, size="footnotesize", eval=!knitr::is_latex_output()---------
#| label: takeaways_talca2
#| fig-cap: Interactive map of take-away outlets in Talca
library(mapview)
mapview(talca_takeaways)


## ----pl_vis0a, size="footnotesize", eval=!knitr::is_latex_output()------------
#| label: gd_dens0a
#| fig-cap: Interactive map of Pomeramia municipalities from rgugik, population density per square kilometre
library(mapview)
mapview(pom5, zcol="density")

## ----pl_vis0c, size="footnotesize"--------------------------------------------
library(giscoR)
pom_gisco <- gisco_get_nuts(year="2021", resolution="01",
 spatialtype="RG", nuts_id="PL63")
pom_gisco_tm <- st_transform(pom_gisco, "EPSG:2180")
pom6 <- st_intersection(pom5, pom_gisco_tm)


## ----pl_vis0c1, size="footnotesize"-------------------------------------------
pom5 |> st_geometry_type() |> table() -> tab5; tab5[tab5>0]
pom6 |> st_geometry_type() |> table() -> tab6; tab6[tab6>0]
pom6 |> st_cast("MULTIPOLYGON") -> pom6


## ----pl_vis0d, size="footnotesize"--------------------------------------------
pom6 |> st_area() |>
 units::set_units("km2") -> pom6$area_km2
pom6 |> st_drop_geometry() |>
 subset(select = c(pop, area_km2)) |>
 apply(1, function(x) x[1]/x[2]) -> pom6$density


## ----pl_vis0e, size="footnotesize", eval=!knitr::is_latex_output()------------
#| label: gd_dens1a
#| fig-cap: Interactive map of Pomeramia municipalities from rgugik, corrected population density per square kilometre
mapview(pom6, zcol="density")

## ----pl_vis1a, size="footnotesize"--------------------------------------------
#| label: pl_vis1a
#| fig-cap: Density plot of population density, Census 2021, Pomeranian municipalities
plot(density(pom6$density))


## ----pl_vis1b, size="footnotesize"--------------------------------------------
#| label: pl_vis1b
#| fig-cap: Population density, Census 2021, Pomeranian municipalities
mf_map(pom6, var="density", type="choro", breaks="geom",
 nbreaks=7)


## ----pl_vis1c, size="footnotesize"--------------------------------------------
#| label: pl_vis1c
#| fig-cap: Municipality type, Pomeranian municipalities
mf_map(pom6, var="type", type="typo")


## ----pl_vis2a, size="footnotesize"--------------------------------------------
pom6$young <- 100*(pom6$m_u15 + pom6$f_u15)/pom6$pop
pom6$young_res <- residuals(lm(young ~ 1, data=pom6))


## ----pl_vis2b, size="footnotesize"--------------------------------------------
#| label: pl_vis2b
#| fig-cap: Proportion of population under 16 years of age, residuals from the mean, Pomeranian municipalities, 2022
tm_shape(pom6) + tm_fill("young_res", style="quantile",
 n=11, midpoint=0, palette="RdBu") + tm_borders()


## ----pl_io1, size="footnotesize", warning=FALSE-------------------------------
fn <- "pom6.gpkg"
if (file.exists(fn)) tull <- file.remove(fn)
try(st_write(pom6, fn))


## ----pl_io1a, size="footnotesize", warning=FALSE, echo=FALSE------------------
lf <- list.files(pattern="pom6.gpkg")
if (length(lf) > 0L) tull <- file.remove(lf)


## ----pl_io2, size="footnotesize", warning=FALSE-------------------------------
str(pom6$FID)
pom6$FID <- 1:nrow(pom6)
st_write(pom6, dsn=fn)


## ----pl_io3a, size="footnotesize"---------------------------------------------
pom6a <- st_read(dsn=fn)


## ----pl_io3b, size="footnotesize"---------------------------------------------
isTRUE(all.equal(st_geometry(pom6), st_geometry(pom6a)))


## ----pl_io3c, size="footnotesize"---------------------------------------------
names(pom6)
names(pom6a)


## ----pl_io3d, size="footnotesize"---------------------------------------------
pom6a$type <- factor(pom6a$type)
pom6a$area_km2 <- units::set_units(pom6a$area_km2, "km2")


