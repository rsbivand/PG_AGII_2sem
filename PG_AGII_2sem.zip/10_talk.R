
## ----imp1, size="footnotesize", message=FALSE---------------------------------
Sys.setenv("PROJ_NETWORK"="ON")
library(spdep)
lw <- nb2listw(unb, style="W")
library(spatialreg)
e <- eigenw(lw)
W <- as(lw, "CsparseMatrix")
trMat <- trW(W, type="mult")

## ----SLM1_pre_ml1, size="footnotesize"----------------------------------------
SLM_pre_maj <- lagsarlm(form_pre_maj, data=eng324, listw=lw, control=list(pre_eig=e))


## ----SLM1_pre_ml2, size="footnotesize"----------------------------------------
set.seed(12345)
R <- 2000
(imp_SLM_pre_maj_tr <- impacts(SLM_pre_maj, tr=trMat, R=R))


## ----SLM1_post_ml1, size="footnotesize"---------------------------------------
SLM_post_maj <- lagsarlm(form_post_maj, data=eng324, listw=lw, control=list(pre_eig=e))

## ----SLM1_post_ml2, size="footnotesize"---------------------------------------
set.seed(12345)
(imp_SLM_post_maj_tr <- impacts(SLM_post_maj, tr=trMat, R=R))


## ----imp_pre_post_tr, size="footnotesize"-------------------------------------
pre_samp <- attr(imp_SLM_pre_maj_tr, "samples")
post_samp <- attr(imp_SLM_post_maj_tr, "samples")
pre_tot <- imp_SLM_pre_maj_tr$sres$total[, c(1:3, 6, 8)]
post_tot <- imp_SLM_post_maj_tr$sres$total[, c(1:3, 6, 8)]
tot <- as.data.frame(rbind(pre_tot, post_tot))
names(tot)[4] <- "log.realWg."
df <- data.frame(tot, rho=c(pre_samp$samples[,2], post_samp$samples[,2]), CCT=factor(c(rep("pre", times=R), rep("post", times=R)), levels=c("pre", "post")))


## ----imp_pre_post_tr_fig0, size="footnotesize", eval=FALSE--------------------
library(tinyplot)
library(grid)
x11()
tinyplot(~ rho | CCT, data=df, type="density", fill="by", palette="dark2", main="rho")
gridGraphics::grid.echo()
g1 <- grid.grab()
dev.off()
x11()
tinyplot(~ log.units. | CCT, data=df, type="density", fill="by", palette="dark2", main="log(units)")
gridGraphics::grid.echo()
g2 <- grid.grab()
dev.off()
x11()
tinyplot(~ house | CCT, data=df, type="density", fill="by", palette="dark2", main="house")
gridGraphics::grid.echo()
g3 <- grid.grab()
dev.off()
x11()
tinyplot(~ log.dens. | CCT, data=df, type="density", fill="by", palette="dark2", main="log(dens)")
gridGraphics::grid.echo()
g4 <- grid.grab()
dev.off()
x11()
tinyplot(~ log.realWg. | CCT, data=df, type="density", fill="by", palette="dark2", main="log(realWg)")
gridGraphics::grid.echo()
g5 <- grid.grab()
dev.off()
x11()
tinyplot(~ MajorityLAB | CCT, data=df, type="density", fill="by", palette="dark2", main="MajorityLAB")
gridGraphics::grid.echo()
g6 <- grid.grab()
dev.off()

## ----imp_pre_post_tr_fig1, size="footnotesize", eval=FALSE--------------------
## png("Images/10_imp_pre_post_tr_fig0.png", width=760, height=1200, pointsize=10)
grid.newpage()
gridExtra::grid.arrange(g1, g2, g3, g4, g5, g6, nrow=3, ncol=2)
## dev.off()


## ----imp_pre_post_tr_tab, size="footnotesize", results="as.is"----------------
#| label: imp_pre_post_tr_tab
#| tab-cap: Spatial coefficient value and chosen variable total impacts and trace-based standard errors, pre-CCT and post-CCT, ML SLM models, 324 English districts
library(tinytable)
sum_imp_SLM_pre_maj_tr <- summary(imp_SLM_pre_maj_tr, short=TRUE, zstats=TRUE)
sum_imp_SLM_post_maj_tr <- summary(imp_SLM_post_maj_tr, short=TRUE, zstats=TRUE)
tf <- data.frame(variable=c(attr(imp_SLM_pre_maj_tr, "bnames")[c(1:3, 6, 8)], "rho"),
  pre=c(sum_imp_SLM_pre_maj_tr$res$total[c(1:3, 6, 8)], SLM_pre_maj$rho),
  pre_se=c(sum_imp_SLM_pre_maj_tr$semat[c(1:3, 6, 8), 3], SLM_pre_maj$rho.se),
  post=c(sum_imp_SLM_post_maj_tr$res$total[c(1:3, 6, 8)], SLM_post_maj$rho),
  post_se=c(sum_imp_SLM_post_maj_tr$semat[c(1:3, 6, 8), 3], SLM_post_maj$rho.se))
tf$variable[4] <- "log(realWg)"
tt(tf, digits=4)


## ----bayes_pre, size="footnotesize", eval=FALSE-------------------------------
set.seed(12345)
SLM_pre_maj_bayes <- spBreg_lag(form_pre_maj, data=eng324, listw=lw, control=list(ndraw=22000L, nomit=2000L, thin=10L))


## ----bayes_post, size="footnotesize", eval=FALSE------------------------------
set.seed(12345)
SLM_post_maj_bayes <- spBreg_lag(form_post_maj, data=eng324, listw=lw, control=list(ndraw=22000L, nomit=2000L, thin=10L))


## ----bayes_pre_post1, size="footnotesize"-------------------------------------
sum_imp_pre <- summary(impacts(SLM_pre_maj_bayes, tr=trMat))
sum_imp_post <- summary(impacts(SLM_post_maj_bayes, tr=trMat))


## ----imp_pre_post_tr_bayes, size="footnotesize"-------------------------------
pre_tot <- sum_imp_pre$sres$total[, c(1:3, 6, 8)]
post_tot <- sum_imp_post$sres$total[, c(1:3, 6, 8)]
R <- nrow(pre_tot)
tot <- as.data.frame(rbind(pre_tot, post_tot))
names(tot)[4] <- "log.realWg."
bdf <- data.frame(tot, rho=c(c(SLM_pre_maj_bayes[, "rho"]), c(SLM_post_maj_bayes[, "rho"])), CCT=factor(c(rep("pre", times=R), rep("post", times=R)), levels=c("pre", "post")))


## ----bayes_pre_post_tr_fig0, size="footnotesize", eval=FALSE------------------
library(tinyplot)
x11()
tinyplot(~ rho | CCT, data=bdf, type="density", fill="by", palette="dark2", main="rho")
gridGraphics::grid.echo()
g1 <- grid.grab()
dev.off()
x11()
tinyplot(~ log.units. | CCT, data=bdf, type="density", fill="by", palette="dark2", main="log(units)")
gridGraphics::grid.echo()
g2 <- grid.grab()
dev.off()
x11()
tinyplot(~ house | CCT, data=bdf, type="density", fill="by", palette="dark2", main="house")
gridGraphics::grid.echo()
g3 <- grid.grab()
dev.off()
x11()
tinyplot(~ log.dens. | CCT, data=bdf, type="density", fill="by", palette="dark2", main="log(dens)")
gridGraphics::grid.echo()
g4 <- grid.grab()
dev.off()
x11()
tinyplot(~ log.realWg. | CCT, data=bdf, type="density", fill="by", palette="dark2", main="log(realWg)")
gridGraphics::grid.echo()
g5 <- grid.grab()
dev.off()
x11()
tinyplot(~ MajorityLAB | CCT, data=bdf, type="density", fill="by", palette="dark2", main="MajorityLAB")
gridGraphics::grid.echo()
g6 <- grid.grab()
dev.off()


## ----bayes_pre_post_tr_fig1, size="footnotesize", eval=FALSE------------------
## png("Images/10_bayes_pre_post_tr_fig0.png", width=760, height=1200, pointsize=10)
grid.newpage()
gridExtra::grid.arrange(g1, g2, g3, g4, g5, g6, nrow=3, ncol=2)
## dev.off()

## ----bayes_pre_post_tr_fig2, size="footnotesize", echo=FALSE, out.width="100%"----
#| label: bayes_pre_post_tr_fig2
#| fig-cap: Shifts in spatial coefficient value and chosen variable total impacts from pre-CCT to post-CCT, SLM models, 324 English districts
knitr::include_graphics("Images/10_bayes_pre_post_tr_fig0.png")


## ----imp_pre_post_ev_tab, size="footnotesize", results="as.is"----------------
#| label: imp_pre_post_ev_tab
#| tab-cap: Spatial coefficient value and variable total impacts, pre-CCT and post-CCT, ML SLM models, 324 English districts
tfe0 <- data.frame(variable=c(names(coef(SLM_pre_maj))[3:10], "rho"), pre=c(impacts(SLM_pre_maj, evalues=e)$total, SLM_pre_maj$rho), post=c(impacts(SLM_post_maj, evalues=e)$total, SLM_post_maj$rho))
tfe0$variable[6] <- "log(realWg)"
tt(tfe0, digits=4) 


## ----gmm_pre_post_maj, size="footnotesize"------------------------------------
library(sphet)
spreg_pre_maj <- spreg(form_pre_maj, data=eng324, listw=lw, model="lag")
spreg_post_maj <- spreg(form_post_maj, data=eng324, listw=lw, model="lag")


## ----imp_gmm_pre_post_maj, size="footnotesize"--------------------------------
imp_spreg_pre_maj <- impacts(spreg_pre_maj, evalues=e, KPformula=TRUE, prt=FALSE)
imp_spreg_post_maj <- impacts(spreg_post_maj, evalues=e, KPformula=TRUE, prt=FALSE)


## ----imp_gmm_pre_post_maj_tab, size="footnotesize", results="as.is"-----------
#| label: imp_gmm_pre_post_maj_tab
#| tab-cap: Spatial coefficient value and chosen variable total impacts and eigenvalue-based standard errors, pre-CCT and post-CCT, GMM SLM models, 324 English districts
etf <- data.frame(variable=c(rownames(imp_spreg_pre_maj[[1]])[c(1:3, 6, 8)], "rho"),
 pre=c(imp_spreg_pre_maj[[1]][c(1:3, 6, 8), 3], c(coef(spreg_pre_maj)[10])),
 pre_se=c(imp_spreg_pre_maj[[2]][c(1:3, 6, 8), 3], sqrt(diag(spreg_pre_maj$var))[10]),
 post=c(imp_spreg_post_maj[[1]][c(1:3, 6, 8), 3], c(coef(spreg_post_maj)[10])),
 post_se=c(imp_spreg_post_maj[[2]][c(1:3, 6, 8), 3], sqrt(diag(spreg_post_maj$var))[10]))
etf$variable[4] <- "log(realWg)"
tt(etf, digits=4)


## ----imp_gmm_pre_post_maj_fig, size="footnotesize", out.width="80%"-----------
#| label: imp_gmm_pre_post_maj_fig
#| fig-cap: Spatial coefficient value and chosen variable total impacts and eigenvalue-based standard errors, pre-CCT and post-CCT, GMM SLM models, 324 English districts
library(tinyplot)
level <- 0.95
a <- (1 - level)/2
a <- c(a, 1 - a)
fac <- qt(a, 324)
edf_pre <- c(imp_spreg_pre_maj[[1]][c(1:3, 6, 8), 3], c(coef(spreg_pre_maj)[10])) + c(imp_spreg_pre_maj[[2]][c(1:3, 6, 8), 3], sqrt(diag(spreg_pre_maj$var))[10]) %o% fac
edf_pre <- data.frame(estimate=c(imp_spreg_pre_maj[[1]][c(1:3, 6, 8), 3], c(coef(spreg_pre_maj)[10])), ci_low=edf_pre[,1], ci_high=edf_pre[,2], vars=rownames(edf_pre))
edf_pre$vars[4] <- "log(realWg)"
edf_post <- c(imp_spreg_post_maj[[1]][c(1:3, 6, 8), 3], c(coef(spreg_post_maj)[10])) + c(imp_spreg_post_maj[[2]][c(1:3, 6, 8), 3], sqrt(diag(spreg_post_maj$var))[10]) %o% fac
edf_post <- data.frame(estimate=c(imp_spreg_post_maj[[1]][c(1:3, 6, 8), 3], c(coef(spreg_post_maj)[10])), ci_low=edf_post[,1], ci_high=edf_post[,2], vars=rownames(edf_post))
edf_post$vars[4] <- "log(realWg)"
opar <- par(mfrow=c(1,2), mar=c(7, 4, 4, 2)+0.1)
with(edf_pre, tinyplot(x=vars, y=estimate, ymin=ci_low, ymax=ci_high, type="pointrange", col="blue4", pch=16, cex=2, main="pre-CCT", ylim=c(-2.9686, 1.3786), grid=TRUE, las=3))
with(edf_post, tinyplot(x=vars, y=estimate, ymin=ci_low, ymax=ci_high, type="pointrange", col="red4", pch=16, cex=2, main="post-CCT", ylim=c(-2.9686, 1.3786), grid=TRUE, las=3))
par(opar)

