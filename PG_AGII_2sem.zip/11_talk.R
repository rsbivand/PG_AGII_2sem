Sys.setenv("PROJ_NETWORK"="ON")

## ----OLS1_pre, size="footnotesize"--------------------------------------------
OLS_pre <- lm(form_pre_maj, data=eng324)
row.names(eng324) <- eng324$NAME
newdata <- eng324
p0 <- predict(OLS_pre, newdata=newdata)
newdata$dens <- exp(log(newdata$dens)+1)
p1 <- predict(OLS_pre, newdata=newdata)
mean(p1-p0)
coefficients(OLS_pre)["log(dens)"]


## ----est1, size="footnotesize", message=FALSE---------------------------------
library(spdep)
lw <- nb2listw(unb, style="W")
library(spatialreg)
e <- eigenw(lw)
W <- as(lw, "CsparseMatrix")
trMat <- trW(W, type="mult")


## ----SLM1_pre_ml1, size="footnotesize"----------------------------------------
SLM_pre_maj <- lagsarlm(form_pre_maj, data=eng324, listw=lw, control=list(pre_eig=e))
SLM_post_maj <- lagsarlm(form_post_maj, data=eng324, listw=lw, control=list(pre_eig=e))

## ----SLM1_pre_ml2, size="footnotesize"----------------------------------------
(imp_SLM_pre_maj_ev <- impacts(SLM_pre_maj, listw=lw, evalue=e))


## ----SLM1_pred_pre0, size="footnotesize"--------------------------------------
IrW <- invIrW(lw, rho=SLM_pre_maj$rho)
p0a <- IrW %*% SLM_pre_maj$X %*% coef(SLM_pre_maj)[-1]
nd <- SLM_pre_maj$X
nd[,4] <- nd[,4] + 1
p1 <- IrW %*% nd %*% coef(SLM_pre_maj)[-1]
mean(p1-p0a)
coefficients(SLM_pre_maj)["log(dens)"]
imp_SLM_pre_maj_ev$total[3]


## ----SLM1_pred_pre1, size="footnotesize"--------------------------------------
p0 <- predict(SLM_pre_maj, newdata=eng324, listw=lw, pred.type="TS", legacy=FALSE)
all.equal(unclass(p0), c(p0a), check.attributes=FALSE)
p1 <- predict(SLM_pre_maj, newdata=newdata, listw=lw, pred.type="TS", legacy=FALSE)
mean(p1-p0)
imp_SLM_pre_maj_ev$total[3]


## ----SLM1_pred_pre_post1, size="footnotesize"---------------------------------
pre_nd <- eng324
pre_nd$realWgPre <- pre_nd$realWgPst
pre_post <- predict(SLM_pre_maj, newdata=pre_nd, listw=lw, pred.type="TS", legacy=FALSE)
eng324$diff <- eng324$realNetPst-eng324$realNetPre
eng324$pre_diff <- eng324$realNetPst-exp(pre_post)


## ----SLM1_pred_pre_post1_fig, size="footnotesize", out.width="100%"-----------
#| label: SLM1_pred_pre_post1_fig
#| fig-cap: Difference between real net expenditure post-CCT and pre-CCT (left), and predictions made with post-CCT independent variables and pre-CCT SLM model coefficients (right)
library(tmap)
tm_shape(eng324) + tm_fill(c("diff", "pre_diff"), n=11, style="pretty", midpoint=0, palette="-RdBu", title="£ 000") + tm_borders() + tm_facets(free.scales=FALSE) + tm_layout(panel.labels=c("Post-CCT - Pre-CCT expenditure", "Post-CCT expenditure - prediction from pre-CCT model"))


## ----SML_pred_oos0r, size="footnotesize"--------------------------------------
eng324$Metrop |> as.character() |> (\(d) sub("london", "metrop", x=d))() |> factor() -> eng324$Metrop


## ----SML_pred_oos1r, size="footnotesize"--------------------------------------
rest <- eng324$region != "NORTH"
eng324_rest <- eng324[rest,]
unb_rest <- subset(unb, rest)
unb_rest
lw_rest <- nb2listw(unb_rest, style="W")
e_rest <- eigenw(lw_rest)


## ----SML_pred_oos2, size="footnotesize"---------------------------------------
SLM_rest <-lagsarlm(form_pre, data=eng324_rest, listw=lw_rest, control=list(pre_eig=e_rest))
eng324$rest_pred <- exp(c(unclass(predict(SLM_rest, newdata=eng324, listw=lw, pred.type="TS", legacy=FALSE))))


## ----SML_pred_oos1n, size="footnotesize"--------------------------------------
eng324_north <- eng324[!rest,]
unb_north <- subset(unb, !rest)
unb_north
lw_north <- nb2listw(unb_north, style="W")
e_north <- eigenw(lw_north)


## ----SML_pred_oos2n, size="footnotesize"--------------------------------------
SLM_north <-lagsarlm(form_pre, data=eng324_north, listw=lw_north, control=list(pre_eig=e_north))
eng324$north_pred <- exp(c(unclass(predict(SLM_north, newdata=eng324, listw=lw, pred.type="TS", legacy=FALSE))))


## ----SLM1_pred_oos_fig, size="footnotesize", out.width="100%"-----------------
#| label: SLM1_pred_oos_fig
#| fig-cap: Difference between real net expenditure post-CCT and pre-CCT (left), and predictions made with post-CCT independent variables and pre-CCT SLM model coefficients (right)
tm_shape(eng324) + tm_fill(c("rest_pred", "north_pred"), n=7, style="quantile", palette="YlOrBr", title="£ 000") + tm_borders(col="grey") + tm_facets(free.scales=FALSE) + tm_layout(panel.labels=c("Predicted pre-CCT expenditure, model without North region", "Predicted pre-CCT expenditure, North region model"))

