## ----car1, size="footnotesize", message=FALSE---------------------------------
Sys.setenv("PROJ_NETWORK"="ON")
library(spdep)
lwB <- nb2listw(unb, style="B")
library(spatialreg)
car1 <- spautolm(form_pre, data=eng324, listw=lwB, family="CAR")
summary(car1, Nagelkerke=TRUE)


## ----car1_ranef, size="footnotesize"------------------------------------------
eng324$ranef_ml <- car1$fit$signal_stochastic


## ----car2, size="footnotesize", message=FALSE, warning=FALSE------------------
library(hglm)
W <- as(lwB, "CsparseMatrix")
car2 <- hglm(fixed=form_pre, random= ~ 1|ID, data=eng324, family = gaussian(), rand.family=CAR(D=W))
car2


## ----car2a, size="footnotesize", message=FALSE, warning=FALSE-----------------
as.character(eng324$NAME[65])


## ----car2_ranef, size="footnotesize"------------------------------------------
eng324$ranef_hglm <- c(unname(car2$ranef))


## ----car3, size="footnotesize"------------------------------------------------
library(mgcv)
names(unb) <- attr(unb, "region.id")
eng324$NAME <- factor(eng324$NAME)
car3 <- gam(update(form_pre, . ~ . + s(NAME, bs="mrf", xt=list(nb=unb))), data=eng324)
summary(car3)


## ----car3_ranef, size="footnotesize"------------------------------------------
eng324$ranef_mrf <- unname(predict(car3, type="terms")[, "s(NAME)"])


## ----car4, size="footnotesize"------------------------------------------------
cbind(ML=coef(car1), HGLM=c(car2$fixef, NA), MRF=c(coef(car3)[1:7], NA))


## ----car4a, size="footnotesize"-----------------------------------------------
cor(st_drop_geometry(eng324)[, c("ranef_ml", "ranef_hglm", "ranef_mrf")])


## ----ranef_vis0, size="footnotesize"------------------------------------------
#| label: ranef_vis0
#| fig-cap: Maps of spatially structured random effects, conditional autoregressive models
library(tmap)
tm_shape(eng324) + tm_fill(c("ranef_ml", "ranef_hglm", "ranef_mrf"), title="random effect", n=9, midpoint=0, style="fisher") + tm_borders() + tm_facets(free.scales=FALSE) + tm_layout(panel.labels=c("ML", "HGLM", "MRF"))


## ----sar1B, size="footnotesize", message=FALSE--------------------------------
sar1B <- spautolm(form_pre, data=eng324, listw=lwB, family="SAR")
summary(sar1B, Nagelkerke=TRUE)


## ----sar0, size="footnotesize", message=FALSE---------------------------------
1/range(eigenw(lwB))
lw <- nb2listw(unb, style="W")
e <- eigenw(lw)
1/range(e)


## ----sar1, size="footnotesize", message=FALSE---------------------------------
sar1 <- spautolm(form_pre, data=eng324, listw=lw, family="SAR", control=list(pre_eig=e))
summary(sar1, Nagelkerke=TRUE)


## ----SEM_pre, size="footnotesize", message=FALSE------------------------------
SEM_pre <- errorsarlm(form_pre, data=eng324, listw=lw, control=list(pre_eig=e))
summary(SEM_pre, Nagelkerke=TRUE)


## ----SEM1_pre, size="footnotesize", message=FALSE-----------------------------
all.equal(coef(SEM_pre)[c(2:8, 1)], coef(sar1), tol=2e-07)


## ----SEM2_pre, size="footnotesize"--------------------------------------------
Hausman.test(SEM_pre)


## ----GNM1_pre, size="footnotesize"--------------------------------------------
GNM_pre <- sacsarlm(form_pre, data=eng324, listw=lw, Durbin=update(form_pre, ~ . - Metrop), control=list(pre_eig1=e, pre_eig2=e))
SAC_pre <- sacsarlm(form_pre, data=eng324, listw=lw, control=list(pre_eig1=e, pre_eig2=e))


## ----LR1_pre, size="footnotesize", warning=FALSE------------------------------
library(lmtest)
lrtest(GNM_pre, SAC_pre)


## ----SDEM1_pre, size="footnotesize"-------------------------------------------
SDEM_pre <- errorsarlm(form_pre, data=eng324, listw=lw, Durbin=update(form_pre, ~ . - Metrop), control=list(pre_eig=e))

## ----SDEM2_pre, size="footnotesize"-------------------------------------------
Hausman.test(SDEM_pre)


## ----SDM1_pre, size="footnotesize"--------------------------------------------
SDM_pre <- lagsarlm(form_pre, data=eng324, listw=lw, Durbin=update(form_pre, ~ . - Metrop), control=list(pre_eig=e))


## ----SDM1_pre_LM, size="footnotesize"-----------------------------------------
c(LM_test=signif(SDM_pre$LMtest), p.value=format.pval((1 - pchisq(SDM_pre$LMtest, 1))))


## ----SLM1_pre, size="footnotesize"--------------------------------------------
SLM_pre <- lagsarlm(form_pre, data=eng324, listw=lw, control=list(pre_eig=e))


## ----SLM1_pre_LM, size="footnotesize"-----------------------------------------
c(LM_test=signif(SLM_pre$LMtest), p.value=format.pval((1 - pchisq(SLM_pre$LMtest, 1))))


## ----SLX1_pre, size="footnotesize"--------------------------------------------
SLX_pre <- lmSLX(form_pre, data=eng324, listw=lw, Durbin=update(form_pre, ~ . - Metrop))


## ----OLS1_pre, size="footnotesize"--------------------------------------------
OLS_pre <- lm(form_pre, data=eng324)


## ----LR2_pre, size="footnotesize", warning=FALSE------------------------------
mlist_pre <- list(GNM=GNM_pre, SAC=SAC_pre, SDEM=SDEM_pre, SDM=SDM_pre, SLX=SLX_pre, SEM=SEM_pre, SLM=SLM_pre, OLS=OLS_pre)
m <- length(mlist_pre)
LR_pre <- matrix(NA, ncol=m, nrow=m)
colnames(LR_pre) <- rownames(LR_pre) <- names(mlist_pre)
for (j in 2:m) LR_pre[1, j] <- lrtest(mlist_pre[[1]],
    mlist_pre[[j]])[[2, "Pr(>Chisq)"]]
for (j in 6:8) LR_pre[2, j] <- lrtest(mlist_pre[[2]],
    mlist_pre[[j]])[[2, "Pr(>Chisq)"]]
for (j in c(5, 6, 8)) LR_pre[3, j] <- lrtest(mlist_pre[[3]],
    mlist_pre[[j]])[[2, "Pr(>Chisq)"]]
for (j in c(5:8)) LR_pre[4, j] <- lrtest(mlist_pre[[4]],
    mlist_pre[[j]])[[2, "Pr(>Chisq)"]]
for (i in 5:7) LR_pre[i, 8] <- lrtest(mlist_pre[[i]],
    mlist_pre[[8]])[[2, "Pr(>Chisq)"]]


## ----LR3_pre, size="footnotesize", out.width="75%"----------------------------
#| label: LR3_pre
#| fig-cap: Heat map of likelihood ratio p-values, pre_CCT models
library(plot.matrix)
library(viridis)
opar <- par(mar=c(3.1, 3.1, 3.1, 7.1), cex.axis=0.8)
plot(LR_pre, breaks=c(0, 10^-(8:0)), col=viridis, las=1)
par(opar)


## ----AIC_pre, size="footnotesize"---------------------------------------------
sort(sapply(mlist_pre, AIC))


## ----BIC_pre, size="footnotesize"---------------------------------------------
sort(sapply(mlist_pre, BIC))


## ----SEM_pre_maj, size="footnotesize", message=FALSE--------------------------
SEM_pre_maj <- errorsarlm(form_pre_maj, data=eng324, listw=lw, control=list(pre_eig=e))


## ----SEM2_pre_maj, size="footnotesize"----------------------------------------
Hausman.test(SEM_pre_maj)


## ----GNM1_pre_maj, size="footnotesize"----------------------------------------
GNM_pre_maj <- sacsarlm(form_pre_maj, data=eng324, listw=lw, Durbin=update(form_pre_maj, ~ . - Metrop - Majority), control=list(pre_eig1=e, pre_eig2=e))
SAC_pre_maj <- sacsarlm(form_pre_maj, data=eng324, listw=lw, control=list(pre_eig1=e, pre_eig2=e))

## ----SDEM1_pre_maj, size="footnotesize"---------------------------------------
SDEM_pre_maj <- errorsarlm(form_pre_maj, data=eng324, listw=lw, Durbin=update(form_pre_maj, ~ . - Metrop - Majority), control=list(pre_eig=e))

## ----SDEM2_pre_maj, size="footnotesize"---------------------------------------
Hausman.test(SDEM_pre_maj)


## ----SDM1_pre_maj, size="footnotesize"----------------------------------------
SDM_pre_maj <- lagsarlm(form_pre_maj, data=eng324, listw=lw, Durbin=update(form_pre_maj, ~ . - Metrop - Majority), control=list(pre_eig=e))

## ----SDM1_pre_maj_LM, size="footnotesize"-------------------------------------
c(LM_test=signif(SDM_pre_maj$LMtest), p.value=format.pval((1 - pchisq(SDM_pre_maj$LMtest, 1))))


## ----SLM1_pre_maj, size="footnotesize"----------------------------------------
SLM_pre_maj <- lagsarlm(form_pre_maj, data=eng324, listw=lw, control=list(pre_eig=e))

## ----SLM1_pre_maj_LM, size="footnotesize"-------------------------------------
c(LM_test=signif(SLM_pre_maj$LMtest), p.value=format.pval((1 - pchisq(SLM_pre_maj$LMtest, 1))))


## ----SLX1_pre_maj, size="footnotesize"----------------------------------------
SLX_pre_maj <- lmSLX(form_pre_maj, data=eng324, listw=lw, Durbin=update(form_pre_maj, ~ . - Metrop - Majority))


## ----OLS1_pre_maj, size="footnotesize"----------------------------------------
OLS_pre_maj <- lm(form_pre_maj, data=eng324)

## ----LR2_pre_maj, size="footnotesize", warning=FALSE--------------------------
mlist_pre_maj <- list(GNM=GNM_pre_maj, SAC=SAC_pre_maj, SDEM=SDEM_pre_maj, SDM=SDM_pre_maj, SLX=SLX_pre_maj, SEM=SEM_pre_maj, SLM=SLM_pre_maj, OLS=OLS_pre_maj)
m <- length(mlist_pre_maj)
LR_pre_maj <- matrix(NA, ncol=m, nrow=m)
colnames(LR_pre_maj) <- rownames(LR_pre_maj) <- names(mlist_pre_maj)
for (j in 2:m) LR_pre_maj[1, j] <- lrtest(mlist_pre_maj[[1]],
    mlist_pre_maj[[j]])[[2, "Pr(>Chisq)"]]
for (j in 6:8) LR_pre_maj[2, j] <- lrtest(mlist_pre_maj[[2]],
    mlist_pre_maj[[j]])[[2, "Pr(>Chisq)"]]
for (j in c(5, 6, 8)) LR_pre_maj[3, j] <- lrtest(mlist_pre_maj[[3]],
    mlist_pre_maj[[j]])[[2, "Pr(>Chisq)"]]
for (j in c(5:8)) LR_pre_maj[4, j] <- lrtest(mlist_pre_maj[[4]],
    mlist_pre_maj[[j]])[[2, "Pr(>Chisq)"]]
for (i in 5:7) LR_pre_maj[i, 8] <- lrtest(mlist_pre_maj[[i]],
    mlist_pre_maj[[8]])[[2, "Pr(>Chisq)"]]


## ----LR3_pre_maj, size="footnotesize", out.width="75%"------------------------
#| label: LR3_pre_maj
#| fig-cap: Heat map of likelihood ratio p-values, pre_CCT models including politiacl control
opar <- par(mar=c(3.1, 3.1, 3.1, 7.1), cex.axis=0.8)
plot(LR_pre_maj, breaks=c(0, 10^-(8:0)), col=viridis, las=1)
par(opar)


## ----AIC_pre_maj, size="footnotesize"-----------------------------------------
sort(sapply(mlist_pre_maj, AIC))


## ----BIC_pre_maj, size="footnotesize"-----------------------------------------
sort(sapply(mlist_pre_maj, BIC))


## ----SEM_post_maj, size="footnotesize", message=FALSE-------------------------
SEM_post_maj <- errorsarlm(form_post_maj, data=eng324, listw=lw, control=list(pre_eig=e))


## ----SEM2_post_maj, size="footnotesize"---------------------------------------
Hausman.test(SEM_post_maj)


## ----GNM1_post_maj, size="footnotesize"---------------------------------------
GNM_post_maj <- sacsarlm(form_post_maj, data=eng324, listw=lw, Durbin=update(form_post_maj, ~ . - Metrop - Majority), control=list(pre_eig1=e, pre_eig2=e))
SAC_post_maj <- sacsarlm(form_post_maj, data=eng324, listw=lw, control=list(pre_eig1=e, pre_eig2=e))

## ----SDEM1_post_maj, size="footnotesize"--------------------------------------
SDEM_post_maj <- errorsarlm(form_post_maj, data=eng324, listw=lw, Durbin=update(form_post_maj, ~ . - Metrop - Majority), control=list(pre_eig=e))

## ----SDEM2_post_maj, size="footnotesize"--------------------------------------
Hausman.test(SDEM_post_maj)


## ----SDM1_post_maj, size="footnotesize"---------------------------------------
SDM_post_maj <- lagsarlm(form_post_maj, data=eng324, listw=lw, Durbin=update(form_post_maj, ~ . - Metrop - Majority), control=list(pre_eig=e))

## ----SDM1_post_maj_LM, size="footnotesize"------------------------------------
c(LM_test=signif(SDM_post_maj$LMtest), p.value=format.pval((1 - pchisq(SDM_post_maj$LMtest, 1))))


## ----SLM1_post_maj, size="footnotesize"---------------------------------------
SLM_post_maj <- lagsarlm(form_post_maj, data=eng324, listw=lw, control=list(pre_eig=e))

## ----SLM1_post_maj_LM, size="footnotesize"------------------------------------
c(LM_test=signif(SLM_post_maj$LMtest), p.value=format.pval((1 - pchisq(SLM_post_maj$LMtest, 1))))


## ----SLX1_post_maj, size="footnotesize"---------------------------------------
SLX_post_maj <- lmSLX(form_post_maj, data=eng324, listw=lw, Durbin=update(form_post_maj, ~ . - Metrop - Majority))


## ----OLS1_post_maj, size="footnotesize"---------------------------------------
OLS_post_maj <- lm(form_post_maj, data=eng324)

## ----LR2_post_maj, size="footnotesize", warning=FALSE-------------------------
mlist_post_maj <- list(GNM=GNM_post_maj, SAC=SAC_post_maj, SDEM=SDEM_post_maj, SDM=SDM_post_maj, SLX=SLX_post_maj, SEM=SEM_post_maj, SLM=SLM_post_maj, OLS=OLS_post_maj)
m <- length(mlist_post_maj)
LR_post_maj <- matrix(NA, ncol=m, nrow=m)
colnames(LR_post_maj) <- rownames(LR_post_maj) <- names(mlist_post_maj)
for (j in 2:m) LR_post_maj[1, j] <- lrtest(mlist_post_maj[[1]],
    mlist_post_maj[[j]])[[2, "Pr(>Chisq)"]]
for (j in 6:8) LR_post_maj[2, j] <- lrtest(mlist_post_maj[[2]],
    mlist_post_maj[[j]])[[2, "Pr(>Chisq)"]]
for (j in c(5, 6, 8)) LR_post_maj[3, j] <- lrtest(mlist_post_maj[[3]],
    mlist_post_maj[[j]])[[2, "Pr(>Chisq)"]]
for (j in c(5:8)) LR_post_maj[4, j] <- lrtest(mlist_post_maj[[4]],
    mlist_post_maj[[j]])[[2, "Pr(>Chisq)"]]
for (i in 5:7) LR_post_maj[i, 8] <- lrtest(mlist_post_maj[[i]],
    mlist_post_maj[[8]])[[2, "Pr(>Chisq)"]]


## ----LR3_post_maj, size="footnotesize", out.width="75%"-----------------------
#| label: LR3_post_maj
#| fig-cap: Heat map of likelihood ratio p-values, post_CCT models including political control
opar <- par(mar=c(3.1, 3.1, 3.1, 7.1), cex.axis=0.8)
plot(LR_post_maj, breaks=c(0, 10^-(8:0)), col=viridis, las=1)
par(opar)


## ----AIC_post_maj, size="footnotesize"----------------------------------------
sort(sapply(mlist_post_maj, AIC))


## ----BIC_post_maj, size="footnotesize"----------------------------------------
sort(sapply(mlist_post_maj, BIC))

